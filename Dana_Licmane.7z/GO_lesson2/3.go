package main

import "fmt"

func main() {
	var cm, m, km float64 = 5, 4, 3

	cmD := cm / 2.54
	cmF := cmD / 12
	cmJ := cmF / 3
	cmM := cmJ / 1760
	fmt.Println(cmD, cmF, cmJ, cmM)

	mD := m / 2.54
	mF := mD / 12
	mJ := mF / 3
	mM := mJ / 1760
	fmt.Println(mD, mF, mJ, mM)

	kmD := km / 2.54
	kmF := kmD / 12
	kmJ := kmF / 3
	kmM := kmJ / 1760
	fmt.Println(kmD, kmF, kmJ, kmM)

}
