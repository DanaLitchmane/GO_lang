package main

import "fmt"

func main() {
	var r, pi float64 = 12, 3.14

	V := 4 / 3 * pi * r * 2 * r
	S := 4 * pi * r * r
	fmt.Println(V)
	fmt.Println(S)
}
