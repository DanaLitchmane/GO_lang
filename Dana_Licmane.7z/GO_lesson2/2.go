package main

import "fmt"

func main() {
	var C float64 = 5

	F := 1.8*C + 32
	K := C + 273.16
	R := 0.8 * C
	fmt.Println(F)
	fmt.Println(K)
	fmt.Println(R)
}
