package main

import "fmt"

func main() {
	var R1, R2 float64 = 12, 45

	RPar := 1 / (1/R1 + 1/R2)
	RPosl := R1 + R2
	fmt.Println(RPar)
	fmt.Println(RPosl)
}
