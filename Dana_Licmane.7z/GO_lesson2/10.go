package main

import (
	"fmt"
	"sort"
)

func main() {

	s := []int{4, 6, 9}
	sort.Ints(s)
	fmt.Println(s)
}
