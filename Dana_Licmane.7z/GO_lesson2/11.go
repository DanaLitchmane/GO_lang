package main

import "fmt"

func main() {
	var num1, num2, num3, num4, max int = 1, 2, 3, 4, 4

	if num1 == num2 || num1 == num3 || num1 == num4 {
		max -= 1
	} else if num2 == num3 || num2 == num4 {
		max -= 1
	} else if num3 == num4 {
		max -= 1
	}
	fmt.Println(max)
}
