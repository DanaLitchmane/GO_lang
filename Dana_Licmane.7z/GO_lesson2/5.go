package main

import (
	"fmt"
	"math"
)

func main() {
	var n float64 = 2

	n2 := math.Pow(n, 2)
	n3 := math.Pow(n2, 3)
	n4 := math.Pow(n3, 4)
	n5 := math.Pow(n4, 5)
	fmt.Println(n2)
	fmt.Println(n3)
	fmt.Println(n4)
	fmt.Println(n5)
}
