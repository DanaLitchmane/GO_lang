package main

import "fmt"

func main() {
	var r, h, pi float64 = 12, 30, 3.14

	V := pi * r * r * h
	S := 2 * pi * r * h
	fmt.Println(V)
	fmt.Println(S)
}
