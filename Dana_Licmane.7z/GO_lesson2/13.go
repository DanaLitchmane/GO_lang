package main

import (
	"fmt"
	"math"
)

func main() {
	var a, b, c float64 = 3, 5, -2
	var d float64
	var x1 float64
	var x2 float64
	d = math.Pow(b, 2) - 4*a*c

	x1 = (-b - math.Sqrt(d)) / 2 * a

	x2 = ((-b + math.Sqrt(d)) / 2 * a)
	if d >= 0 {
		fmt.Println(x1, x2)
	} else if d == 0 {
		fmt.Println(x1)
	} else if d <= 0 {
		fmt.Print("Нет корней")
	}
}
