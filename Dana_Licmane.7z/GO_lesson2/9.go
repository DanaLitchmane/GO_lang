package main

import "fmt"

func main() {
	var sec float64 = 12

	Min := sec / 60
	Hours := Min / 60
	Day := Hours / 24
	fmt.Println(Day)
	fmt.Println(Hours)
	fmt.Println(Min)
}
