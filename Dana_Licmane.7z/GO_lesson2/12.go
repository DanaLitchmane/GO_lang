package main

import (
	"fmt"
	"math"
)

func main() {
	var num1, num2, num3, num4, num5 float64 = 3, 5, 2, 9, 7
	var max float64
	var min float64

	max = math.Max(num1, num2)
	max = math.Max(max, num3)
	max = math.Max(max, num4)
	max = math.Max(max, num5)

	fmt.Println(max)

	min = math.Min(num1, num2)
	min = math.Min(min, num3)
	min = math.Min(min, num4)
	min = math.Min(min, num5)

	fmt.Println(min)
}
