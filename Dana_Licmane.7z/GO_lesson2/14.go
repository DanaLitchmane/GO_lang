package main

import (
	"fmt"
	"math"
)

func main() {
	var a, b float64 = 4, 2
	var g, r, t, i, o, p float64

	g = a + b 
	r = a - b
	t = b - a
	i = a * b
	if (b != 0) {
		o = a / b
	} 
	if (a != 0) {
		p = b/a
	}

	
	if g==r||g==t||g==i||g==o||g==p {
		fmt.Println(g)
	} else if {
		r==t||r==i||r==o||r==p {
			fmt.Println(r)
		} else if {
			t==i||t==o||t==p {
				fmt.Println(t)
			} else if o==p {
				fmt.Println(o)
			} else if o != p{
				fmt.Println(p)
			}
		}
	}
}	