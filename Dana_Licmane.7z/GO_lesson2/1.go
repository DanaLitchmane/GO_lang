package main

import "fmt"

func main() {
	var V1, V2, S int = 5, 7, 45

	t := S / (V1 + V2)
	fmt.Println(t)
}
