package main

import "fmt"

func main() {
	var H, M int = 12, 30

	U := (H+M/60)*30 - 6*M
	fmt.Println(U)
}
