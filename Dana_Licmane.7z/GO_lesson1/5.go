package main

import (
	"fmt"
	"math"
)

func main() {
	var R, c, S, p float64

	p = 3.14
	R = 23
	c = 2 * p * R
	S = p * math.Pow(R, 2)
	fmt.Println(c)
	fmt.Println(S)
}