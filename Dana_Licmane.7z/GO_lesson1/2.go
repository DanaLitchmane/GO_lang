package main

import "fmt"
func main() {
	var a, b, c, V, S int

	a = 12
	b = 3
	c = 5
	V = a * b * c
	S = 2 * (a * b + a * c + b * c)
	fmt.Print(V)
	fmt.Println(S)
}