package main

import "fmt"

func main() {
	var kmh, ms, mmin int

	kmh = 23
	ms = kmh * 1000 / 3600
	mmin = ms * 60
	fmt.Println(ms)
	fmt.Println(mmin)
}