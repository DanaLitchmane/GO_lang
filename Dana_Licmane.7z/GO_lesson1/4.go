package main

import "fmt"

func main() {
	var V, T, S int

	V = 23
	T = 3
	S = V * T 
	fmt.Print(S)
}