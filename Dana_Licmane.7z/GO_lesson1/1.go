package main

import "fmt"

func main(){
	var a,b,P,S int

	//a=12
	//b=3

	fmt.Scan(&a)
	fmt.Scan(&b)

	P = 2*a + 2*b
	S = a*b
	fmt.Println(S)
	fmt.Print(P)
}