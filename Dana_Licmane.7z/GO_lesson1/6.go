package main

import (
	"fmt"
	"math"
)

func main() {
	var n, n2, n3, n4 float64

	n = 4
	n2 = n * math.Pow(n, 2)
	n3 = n * math.Pow(n, 3)
	n4 = n * math.Pow(n, 4)
	fmt.Println(n2)
	fmt.Println(n3)
	fmt.Println(n4)
}