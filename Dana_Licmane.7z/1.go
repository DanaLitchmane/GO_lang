package main

import (
	"fmt"
	"math"
)

func main() {
	var x1, x2, y1, y2, d, d1, d2, d3, d4, d5, A, B, C, F float64

	x1 = 3
	x2 = 5
	y1 = 1
	y2 = 2
	d = x2 - x1
	d1 = y2 - y1
	d2 = d * math.Pow(d, 2)
	d3 = d1 * math.Pow(d1, 2)
	d4 = d2 + d3
	d5 = math.Sqrt(d4)
	fmt.Println(d5)

	A = math.Abs(y1 - y2)
	B = math.Abs(x1 - x2)
	C = math.Pow(B, 2) * math.Pow(A, 2)
	F = math.Sqrt(C)
	fmt.Println(F)

}
